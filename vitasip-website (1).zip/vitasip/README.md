# VitaSip — Refreshing Fruit-Based Beverages

**Fictional FMCG beverage brand** created for an academic website development and digital marketing project.

**Tagline:** Sip Healthy. Live Happy.

This is a polished, production-oriented demonstration website built with React, TypeScript, Tailwind CSS and React Router. It showcases three imaginary flavours (Lemon Mint, Mango Burst, Berry Fresh), a working demo cart, subscription plan UI, blog, contact form and account screens.

> **Important:** VitaSip is not a real company. All products, prices, reviews, testimonials and contact details are sample/demo data. Payment, order fulfilment, newsletter delivery and secure authentication require backend configuration and are clearly marked as non-functional in the prototype.

## Tech Stack

- **Frontend:** React 19 + TypeScript + Vite
- **Styling:** Tailwind CSS v4
- **Icons:** Lucide React
- **Routing:** React Router v7
- **State:** React Context + localStorage (demo cart)
- **Backend (prepared):** Vercel Functions + Neon PostgreSQL
- **Deployment target:** Vercel
- **Version control:** GitHub

## Quick Start

```bash
cd vitasip
npm install
npm run dev
npm run build
npm run preview
```

## Project Structure

```
src/
  components/   # Logo, Navbar, Footer, ProductCard, Layout
  context/      # CartContext (persisted demo cart)
  data/         # products, subscriptions, blog, testimonials
  pages/        # All route pages
  types/        # TypeScript interfaces
api/            # Example Vercel function for enquiries
db/             # PostgreSQL schema
public/images/  # SVG product mockups and placeholders
```

## Features

| Feature | Status |
|---------|--------|
| Responsive multipage site | Working |
| Product catalogue + filters | Working |
| Product detail pages | Working |
| Demo shopping cart (localStorage) | Working |
| Subscription plan selection (UI) | Demo only |
| Contact form with validation | UI + error when API missing |
| Blog + article pages | Working |
| Account login/signup UI | Demo only |
| SEO meta tags, semantic HTML | Yes |
| Neon schema + API example | Prepared |

## Database & Backend

1. Create a free Neon project: https://neon.tech
2. Copy the connection string into `.env.local` as `DATABASE_URL`
3. Run `db/schema.sql` against your Neon database
4. Deploy the `api/enquiries.ts` function on Vercel
5. Never commit real credentials or expose `DATABASE_URL` to the browser

## Deployment (Vercel)

1. Push the repository to GitHub
2. Import the project in Vercel
3. Add environment variables in the Vercel dashboard
4. Deploy — Vite builds automatically

## Colour Palette

- Fresh Green: #166534
- Lime Green: #D9ED92
- Mango Yellow: #F4B942
- Dark Green: #25352B
- Warm White: #FFFFFF

Created for academic demonstration. Do not present VitaSip as an existing commercial brand.
