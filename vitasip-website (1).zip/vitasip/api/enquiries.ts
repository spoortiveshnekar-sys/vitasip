/**
 * Example Vercel Serverless Function / API route for contact enquiries.
 * Place in /api/enquiries.ts when using Vercel.
 * Requires DATABASE_URL environment variable pointing to Neon PostgreSQL.
 *
 * NEVER expose DATABASE_URL in frontend code.
 */

// import { Pool } from '@neondatabase/serverless'; // or 'pg'

export const config = {
  runtime: 'edge', // or 'nodejs'
};

interface EnquiryBody {
  name: string;
  email: string;
  phone?: string;
  organisation?: string;
  enquiryType: string;
  orderNumber?: string;
  message: string;
  consent: boolean;
}

export default async function handler(request: Request): Promise<Response> {
  if (request.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405 });
  }

  try {
    const body = (await request.json()) as EnquiryBody;

    // Basic validation
    if (!body.name?.trim() || !body.email?.trim() || !body.message?.trim() || !body.consent) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), { status: 400 });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(body.email)) {
      return new Response(JSON.stringify({ error: 'Invalid email' }), { status: 400 });
    }

    // Uncomment and configure when Neon is ready:
    /*
    const pool = new Pool({ connectionString: process.env.DATABASE_URL });
    await pool.query(
      `INSERT INTO enquiries (name, email, phone, enquiry_type, order_number, message, consent, created_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
      [
        body.name.trim(),
        body.email.trim().toLowerCase(),
        body.phone || null,
        body.enquiryType,
        body.orderNumber || null,
        body.message.trim(),
        body.consent,
      ]
    );
    await pool.end();
    */

    // For prototype without DB:
    console.log('Enquiry received (not persisted):', body);

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err) {
    console.error(err);
    return new Response(JSON.stringify({ error: 'Server error' }), { status: 500 });
  }
}
