-- VitaSip Neon PostgreSQL schema (prototype)
-- Run against your Neon database after creating the project.

CREATE TABLE IF NOT EXISTS enquiries (
  id            SERIAL PRIMARY KEY,
  name          VARCHAR(200) NOT NULL,
  email         VARCHAR(255) NOT NULL,
  phone         VARCHAR(30),
  organisation  VARCHAR(200),
  enquiry_type  VARCHAR(100) NOT NULL,
  order_number  VARCHAR(50),
  message       TEXT NOT NULL,
  consent       BOOLEAN NOT NULL DEFAULT false,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS newsletter_subscribers (
  id            SERIAL PRIMARY KEY,
  email         VARCHAR(255) NOT NULL UNIQUE,
  consent       BOOLEAN NOT NULL DEFAULT true,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Future tables (structure only)

CREATE TABLE IF NOT EXISTS products (
  id            SERIAL PRIMARY KEY,
  slug          VARCHAR(100) NOT NULL UNIQUE,
  name          VARCHAR(200) NOT NULL,
  description   TEXT,
  price_paise   INTEGER NOT NULL, -- store as integer paise
  pack_size     VARCHAR(50),
  flavour       VARCHAR(50),
  in_stock      BOOLEAN DEFAULT true,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS customers (
  id            SERIAL PRIMARY KEY,
  email         VARCHAR(255) NOT NULL UNIQUE,
  name          VARCHAR(200),
  password_hash VARCHAR(255), -- use proper hashing (bcrypt/argon2)
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
  id            SERIAL PRIMARY KEY,
  customer_id   INTEGER REFERENCES customers(id),
  status        VARCHAR(50) DEFAULT 'pending',
  total_paise   INTEGER NOT NULL,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_items (
  id            SERIAL PRIMARY KEY,
  order_id      INTEGER REFERENCES orders(id) ON DELETE CASCADE,
  product_id    INTEGER REFERENCES products(id),
  quantity      INTEGER NOT NULL,
  unit_price_paise INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS subscription_plans (
  id            SERIAL PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  frequency     VARCHAR(20) NOT NULL,
  bottles       INTEGER NOT NULL,
  price_paise   INTEGER NOT NULL,
  active        BOOLEAN DEFAULT true
);

CREATE INDEX IF NOT EXISTS idx_enquiries_email ON enquiries(email);
CREATE INDEX IF NOT EXISTS idx_enquiries_created ON enquiries(created_at DESC);
