import { Link } from 'react-router-dom';
import { Instagram, Twitter, Facebook, Linkedin } from 'lucide-react';
import Logo from './Logo';

export default function Footer() {
  return (
    <footer className="bg-dark-green text-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="space-y-4">
            <Logo className="[&_span]:text-lime-green [&_span:last-child]:text-white" />
            <p className="text-sm text-lime-green/90 font-medium">Sip Healthy. Live Happy.</p>
            <p className="text-sm text-white/70 leading-relaxed">
              VitaSip is a fictional FMCG beverage brand created for an academic project. We imagine refreshing
              fruit-based drinks for young Indian consumers who value flavour, convenience and transparent information.
            </p>
          </div>

          {/* Quick links */}
          <div>
            <h3 className="font-heading font-semibold text-lime-green mb-4">Explore</h3>
            <ul className="space-y-2 text-sm text-white/80">
              <li><Link to="/about" className="hover:text-lime-green transition-colors">About Us</Link></li>
              <li><Link to="/products" className="hover:text-lime-green transition-colors">Our Products</Link></li>
              <li><Link to="/how-it-works" className="hover:text-lime-green transition-colors">How It Works</Link></li>
              <li><Link to="/subscriptions" className="hover:text-lime-green transition-colors">Subscriptions</Link></li>
              <li><Link to="/blog" className="hover:text-lime-green transition-colors">Blog</Link></li>
              <li><Link to="/contact" className="hover:text-lime-green transition-colors">Contact Us</Link></li>
            </ul>
          </div>

          {/* Products */}
          <div>
            <h3 className="font-heading font-semibold text-lime-green mb-4">Flavours</h3>
            <ul className="space-y-2 text-sm text-white/80">
              <li><Link to="/products/lemon-mint" className="hover:text-lime-green transition-colors">Lemon Mint</Link></li>
              <li><Link to="/products/mango-burst" className="hover:text-lime-green transition-colors">Mango Burst</Link></li>
              <li><Link to="/products/berry-fresh" className="hover:text-lime-green transition-colors">Berry Fresh</Link></li>
            </ul>
            <h3 className="font-heading font-semibold text-lime-green mt-6 mb-4">Legal</h3>
            <ul className="space-y-2 text-sm text-white/80">
              <li><Link to="/privacy" className="hover:text-lime-green transition-colors">Privacy Policy</Link></li>
              <li><Link to="/terms" className="hover:text-lime-green transition-colors">Terms &amp; Conditions</Link></li>
              <li><Link to="/shipping" className="hover:text-lime-green transition-colors">Shipping &amp; Refunds</Link></li>
            </ul>
          </div>

          {/* Contact & social */}
          <div>
            <h3 className="font-heading font-semibold text-lime-green mb-4">Get in Touch</h3>
            <ul className="space-y-2 text-sm text-white/80">
              <li>Email: hello@vitasip.example</li>
              <li>Phone: +91 98765 43210</li>
              <li>Address: [Placeholder], Bengaluru, India</li>
            </ul>
            <p className="mt-2 text-xs text-white/50">Placeholder contact details for prototype only.</p>
            <div className="flex gap-3 mt-5">
              <a href="#" className="p-2 rounded-full bg-white/10 hover:bg-lime-green hover:text-dark-green transition-colors" aria-label="Instagram"><Instagram className="h-4 w-4" /></a>
              <a href="#" className="p-2 rounded-full bg-white/10 hover:bg-lime-green hover:text-dark-green transition-colors" aria-label="Twitter"><Twitter className="h-4 w-4" /></a>
              <a href="#" className="p-2 rounded-full bg-white/10 hover:bg-lime-green hover:text-dark-green transition-colors" aria-label="Facebook"><Facebook className="h-4 w-4" /></a>
              <a href="#" className="p-2 rounded-full bg-white/10 hover:bg-lime-green hover:text-dark-green transition-colors" aria-label="LinkedIn"><Linkedin className="h-4 w-4" /></a>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-white/10 flex flex-col sm:flex-row justify-between gap-4 text-sm text-white/50">
          <p>© {new Date().getFullYear()} VitaSip. Fictional brand for academic demonstration. All product details, prices and reviews are sample data.</p>
          <p>Built with React, TypeScript &amp; Tailwind CSS.</p>
        </div>
      </div>
    </footer>
  );
}
