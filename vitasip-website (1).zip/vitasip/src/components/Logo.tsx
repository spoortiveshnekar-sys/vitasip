import { Link } from 'react-router-dom';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export default function Logo({ className = '', size = 'md' }: LogoProps) {
  const sizes = {
    sm: 'text-xl',
    md: 'text-2xl',
    lg: 'text-3xl',
  };

  return (
    <Link to="/" className={`inline-flex items-center gap-2 font-heading font-bold ${sizes[size]} ${className}`}>
      <span className="flex h-9 w-9 items-center justify-center rounded-full bg-fresh-green text-lime-green text-lg">
        V
      </span>
      <span className="text-fresh-green">
        Vita<span className="text-dark-green">Sip</span>
      </span>
    </Link>
  );
}
