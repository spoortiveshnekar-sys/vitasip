import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { Menu, X, ShoppingCart, Search, User } from 'lucide-react';
import Logo from './Logo';
import { useCart } from '../context/CartContext';

const navLinks = [
  { to: '/', label: 'Home' },
  { to: '/about', label: 'About Us' },
  { to: '/products', label: 'Our Products' },
  { to: '/how-it-works', label: 'How It Works' },
  { to: '/subscriptions', label: 'Subscriptions' },
  { to: '/blog', label: 'Blog' },
  { to: '/contact', label: 'Contact Us' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const { totalItems } = useCart();

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur border-b border-gray-100 shadow-sm">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between gap-4">
          <Logo size="md" />

          {/* Desktop nav */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                end={link.to === '/'}
                className={({ isActive }) =>
                  `px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-lime-green/40 text-fresh-green'
                      : 'text-dark-green/80 hover:text-fresh-green hover:bg-lime-green/20'
                  }`
                }
              >
                {link.label}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-2 sm:gap-3">
            <button
              type="button"
              className="p-2 rounded-full text-dark-green/70 hover:bg-lime-green/30 hover:text-fresh-green transition-colors"
              aria-label="Search"
            >
              <Search className="h-5 w-5" />
            </button>
            <Link
              to="/account"
              className="p-2 rounded-full text-dark-green/70 hover:bg-lime-green/30 hover:text-fresh-green transition-colors"
              aria-label="Account"
            >
              <User className="h-5 w-5" />
            </Link>
            <Link
              to="/cart"
              className="relative p-2 rounded-full text-dark-green/70 hover:bg-lime-green/30 hover:text-fresh-green transition-colors"
              aria-label="Shopping cart"
            >
              <ShoppingCart className="h-5 w-5" />
              {totalItems > 0 && (
                <span className="absolute -top-0.5 -right-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-fresh-green text-[10px] font-bold text-white">
                  {totalItems > 9 ? '9+' : totalItems}
                </span>
              )}
            </Link>
            <Link
              to="/products"
              className="hidden sm:inline-flex items-center rounded-full bg-fresh-green px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-dark-green transition-colors"
            >
              Shop Now
            </Link>
            <button
              type="button"
              className="lg:hidden p-2 rounded-lg text-dark-green hover:bg-lime-green/30"
              onClick={() => setOpen(!open)}
              aria-label={open ? 'Close menu' : 'Open menu'}
            >
              {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="lg:hidden border-t border-gray-100 bg-white">
          <nav className="flex flex-col px-4 py-3 gap-1">
            {navLinks.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                end={link.to === '/'}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  `px-3 py-2.5 rounded-lg text-sm font-medium ${
                    isActive ? 'bg-lime-green/40 text-fresh-green' : 'text-dark-green hover:bg-lime-green/20'
                  }`
                }
              >
                {link.label}
              </NavLink>
            ))}
            <Link
              to="/products"
              onClick={() => setOpen(false)}
              className="mt-2 inline-flex justify-center rounded-full bg-fresh-green px-4 py-2.5 text-sm font-semibold text-white"
            >
              Shop Now
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
