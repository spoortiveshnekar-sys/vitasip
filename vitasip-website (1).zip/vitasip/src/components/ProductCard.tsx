import { Link } from 'react-router-dom';
import { ShoppingCart, Star } from 'lucide-react';
import type { Product } from '../types';
import { useCart } from '../context/CartContext';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart();

  return (
    <article className="group flex flex-col rounded-2xl bg-white border border-gray-100 shadow-sm hover:shadow-md transition-shadow overflow-hidden">
      <Link to={`/products/${product.slug}`} className="relative aspect-[3/4] bg-gradient-to-b from-lime-green/20 to-white p-6 flex items-center justify-center">
        <img
          src={product.image}
          alt={`${product.name} bottle mockup – conceptual visual for imaginary brand`}
          className="h-full w-auto object-contain group-hover:scale-105 transition-transform duration-300"
        />
        {product.isBestSeller && (
          <span className="absolute top-3 left-3 rounded-full bg-mango-yellow px-2.5 py-0.5 text-xs font-semibold text-dark-green">
            Bestseller
          </span>
        )}
      </Link>
      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-center gap-1 text-mango-yellow mb-1">
          <Star className="h-3.5 w-3.5 fill-current" />
          <span className="text-xs font-medium text-dark-green/70">
            {product.rating} · {product.reviewCount} reviews <span className="text-dark-green/40">(sample)</span>
          </span>
        </div>
        <h3 className="font-heading font-semibold text-lg text-dark-green">
          <Link to={`/products/${product.slug}`} className="hover:text-fresh-green transition-colors">
            {product.name}
          </Link>
        </h3>
        <p className="mt-1 text-sm text-dark-green/70 line-clamp-2 flex-1">{product.shortDescription}</p>
        <div className="mt-4 flex items-center justify-between gap-2">
          <div>
            <span className="text-lg font-bold text-fresh-green">₹{product.price}</span>
            <span className="text-xs text-dark-green/50 ml-1">/ {product.packSize}</span>
          </div>
          <div className="flex gap-2">
            <Link
              to={`/products/${product.slug}`}
              className="rounded-full border border-fresh-green/30 px-3 py-1.5 text-xs font-medium text-fresh-green hover:bg-lime-green/30 transition-colors"
            >
              View Details
            </Link>
            <button
              type="button"
              onClick={() => addItem(product)}
              className="inline-flex items-center gap-1 rounded-full bg-fresh-green px-3 py-1.5 text-xs font-semibold text-white hover:bg-dark-green transition-colors"
              aria-label={`Add ${product.name} to cart`}
            >
              <ShoppingCart className="h-3.5 w-3.5" />
              Add
            </button>
          </div>
        </div>
      </div>
    </article>
  );
}
