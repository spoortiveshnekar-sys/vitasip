import type { BlogPost } from '../types';

export const blogPosts: BlogPost[] = [
  {
    id: '1',
    slug: 'how-to-read-beverage-ingredient-labels',
    title: 'How to Read Beverage Ingredient Labels',
    summary:
      'Understanding what goes into packaged drinks helps you make informed choices. Here is a simple guide to reading labels.',
    content: `
      <p>When you pick up a bottle of fruit drink, the ingredient list and nutrition panel can tell you a lot. Ingredients are usually listed in descending order by weight.</p>
      <p>Look for the primary fruit or juice source near the top. Added sugars, acids for tartness, and natural or artificial flavours often follow. At VitaSip we aim for clear, readable labels so you always know what you are sipping.</p>
      <p>Check the serving size and compare energy and sugar values across products. Storage instructions and best-before dates help keep your drinks tasting their best.</p>
      <p>This article is general guidance only and does not constitute nutritional advice. Always refer to the label on the specific product you purchase.</p>
    `,
    image: '/images/blog-labels.svg',
    date: '2025-09-12',
    author: 'VitaSip Team',
    tags: ['ingredients', 'labels', 'tips'],
  },
  {
    id: '2',
    slug: 'finding-refreshing-drinks-for-a-busy-day',
    title: 'Finding Refreshing Drinks for a Busy Day',
    summary:
      'Between classes, meetings and commute, staying refreshed matters. Discover practical ways to fit enjoyable beverages into a packed schedule.',
    content: `
      <p>Busy days call for convenient options. Ready-to-drink fruit beverages can sit in a bag or desk drawer and be ready when you need a break.</p>
      <p>Consider pack sizes that match your routine — single bottles for on-the-go, or multi-packs for home and office. Flavour variety keeps things interesting across the week.</p>
      <p>VitaSip is designed with young Indian consumers in mind: portable packaging, familiar fruit flavours, and transparent product information.</p>
    `,
    image: '/images/blog-busy.svg',
    date: '2025-08-28',
    author: 'VitaSip Team',
    tags: ['lifestyle', 'convenience'],
  },
  {
    id: '3',
    slug: 'discovering-different-fruit-flavours',
    title: 'Discovering Different Fruit Flavours',
    summary:
      'From zesty citrus to tropical mango and vibrant berries, fruit flavours offer endless everyday enjoyment.',
    content: `
      <p>Fruit-based drinks let you explore taste profiles without complicated preparation. Lemon and mint deliver crisp freshness; mango brings tropical sweetness; berries add a lively character.</p>
      <p>Trying a few options helps you identify personal favourites. Many people rotate flavours across the week to keep refreshment interesting.</p>
      <p>Explore our Lemon Mint, Mango Burst and Berry Fresh range to find your preferred everyday sip.</p>
    `,
    image: '/images/blog-flavours.svg',
    date: '2025-08-10',
    author: 'VitaSip Team',
    tags: ['flavours', 'products'],
  },
  {
    id: '4',
    slug: 'what-to-consider-when-choosing-packaged-beverages',
    title: 'What to Consider When Choosing Packaged Beverages',
    summary:
      'Packaging, price, flavour and transparency all play a role when selecting drinks for regular consumption.',
    content: `
      <p>Convenience is a major factor for students and professionals. Look for resealable bottles, clear labelling and reliable availability.</p>
      <p>Price per pack and multi-buy options matter for everyday budgets. Sample different flavours before committing to larger packs or subscriptions.</p>
      <p>Transparent ingredient lists and accessible contact information build trust. VitaSip aims to provide all of the above for its target audience in Tier 1 and Tier 2 cities.</p>
    `,
    image: '/images/blog-choose.svg',
    date: '2025-07-22',
    author: 'VitaSip Team',
    tags: ['buying-guide', 'tips'],
  },
  {
    id: '5',
    slug: 'simple-tips-for-storing-packaged-drinks',
    title: 'Simple Tips for Storing Packaged Drinks',
    summary:
      'Proper storage keeps flavour and quality intact from the moment you buy until the last sip.',
    content: `
      <p>Keep unopened bottles in a cool, dry place away from direct sunlight. Once opened, refrigerate and finish within the recommended time on the label — typically a few days.</p>
      <p>Avoid extreme temperatures during transport. When ordering online, choose delivery slots that minimise time at the doorstep in hot weather.</p>
      <p>Always check the best-before date and follow any specific storage guidance printed on the pack.</p>
    `,
    image: '/images/blog-storage.svg',
    date: '2025-07-05',
    author: 'VitaSip Team',
    tags: ['storage', 'tips'],
  },
];

export const getPostBySlug = (slug: string): BlogPost | undefined =>
  blogPosts.find((p) => p.slug === slug);
