import type { Product } from '../types';

export const products: Product[] = [
  {
    id: '1',
    name: 'VitaSip Lemon Mint',
    slug: 'lemon-mint',
    description:
      'A refreshing blend of zesty lemon and cool mint. VitaSip Lemon Mint is crafted for those everyday moments when you need a crisp, invigorating drink. Perfect for college days, office breaks, or sunny afternoons.',
    shortDescription: 'Zesty lemon meets cool mint for everyday refreshment.',
    price: 40,
    packSize: '250 ml',
    flavour: 'lemon-mint',
    category: 'Fruit Drinks',
    image: '/images/lemon-mint.svg',
    images: ['/images/lemon-mint.svg', '/images/lemon-mint-2.svg'],
    ingredients: ['Water', 'Lemon Juice Concentrate', 'Mint Extract', 'Sugar', 'Citric Acid', 'Natural Flavours'],
    nutrition: [
      { label: 'Energy', value: '45 kcal' },
      { label: 'Carbohydrates', value: '11 g' },
      { label: 'Sugars', value: '10 g' },
      { label: 'Protein', value: '0 g' },
      { label: 'Fat', value: '0 g' },
    ],
    allergens: 'None declared. Produced in a facility that may handle common allergens.',
    storage: 'Store in a cool, dry place. Refrigerate after opening and consume within 3 days.',
    inStock: true,
    rating: 4.6,
    reviewCount: 128,
    isBestSeller: true,
  },
  {
    id: '2',
    name: 'VitaSip Mango Burst',
    slug: 'mango-burst',
    description:
      'Experience the tropical sweetness of ripe mangoes in every sip. VitaSip Mango Burst brings the taste of summer to your daily routine with a smooth, fruity flavour that young professionals and students love.',
    shortDescription: 'Tropical mango flavour for a burst of everyday joy.',
    price: 45,
    packSize: '250 ml',
    flavour: 'mango-burst',
    category: 'Fruit Drinks',
    image: '/images/mango-burst.svg',
    images: ['/images/mango-burst.svg', '/images/mango-burst-2.svg'],
    ingredients: ['Water', 'Mango Pulp', 'Sugar', 'Citric Acid', 'Natural Mango Flavour', 'Colour (Natural)'],
    nutrition: [
      { label: 'Energy', value: '52 kcal' },
      { label: 'Carbohydrates', value: '13 g' },
      { label: 'Sugars', value: '12 g' },
      { label: 'Protein', value: '0.2 g' },
      { label: 'Fat', value: '0 g' },
    ],
    allergens: 'None declared. Produced in a facility that may handle common allergens.',
    storage: 'Store in a cool, dry place. Refrigerate after opening and consume within 3 days.',
    inStock: true,
    rating: 4.8,
    reviewCount: 215,
    isBestSeller: true,
  },
  {
    id: '3',
    name: 'VitaSip Berry Fresh',
    slug: 'berry-fresh',
    description:
      'A vibrant mix of berry notes that deliver a lively, refreshing taste. VitaSip Berry Fresh is designed for health-conscious consumers who want flavour without complication — convenient packaging and clear ingredient information included.',
    shortDescription: 'Vibrant berry flavours for a lively refreshment experience.',
    price: 50,
    packSize: '250 ml',
    flavour: 'berry-fresh',
    category: 'Fruit Drinks',
    image: '/images/berry-fresh.svg',
    images: ['/images/berry-fresh.svg', '/images/berry-fresh-2.svg'],
    ingredients: ['Water', 'Berry Juice Blend (Strawberry, Blueberry, Raspberry)', 'Sugar', 'Citric Acid', 'Natural Flavours'],
    nutrition: [
      { label: 'Energy', value: '48 kcal' },
      { label: 'Carbohydrates', value: '12 g' },
      { label: 'Sugars', value: '11 g' },
      { label: 'Protein', value: '0.1 g' },
      { label: 'Fat', value: '0 g' },
    ],
    allergens: 'None declared. Produced in a facility that may handle common allergens.',
    storage: 'Store in a cool, dry place. Refrigerate after opening and consume within 3 days.',
    inStock: true,
    rating: 4.5,
    reviewCount: 97,
    isBestSeller: false,
  },
];

export const getProductBySlug = (slug: string): Product | undefined =>
  products.find((p) => p.slug === slug);

export const getRelatedProducts = (currentId: string, limit = 2): Product[] =>
  products.filter((p) => p.id !== currentId).slice(0, limit);
