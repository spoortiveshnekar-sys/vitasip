import type { SubscriptionPlan } from '../types';

export const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: 'weekly-basic',
    name: 'Weekly Essentials',
    frequency: 'weekly',
    bottles: 6,
    price: 249,
    description: 'A convenient 6-bottle pack delivered every week. Mix and match flavours or stick to your favourites.',
    features: [
      '6 bottles per week',
      'Choose any combination of flavours',
      'Free delivery on orders above ₹499 (illustrative)',
      'Flexible pause or skip (demo)',
    ],
  },
  {
    id: 'weekly-plus',
    name: 'Weekly Plus',
    frequency: 'weekly',
    bottles: 12,
    price: 459,
    description: 'Double the refreshment. Ideal for households or share with friends on campus.',
    features: [
      '12 bottles per week',
      'Full flavour selection',
      'Priority dispatch (proposed)',
      'Flexible management options (demo)',
    ],
    popular: true,
  },
  {
    id: 'monthly-standard',
    name: 'Monthly Standard',
    frequency: 'monthly',
    bottles: 24,
    price: 899,
    description: 'Stock up for the month with our most popular pack size. Great value for regular drinkers.',
    features: [
      '24 bottles per month',
      'Save vs individual bottles (illustrative)',
      'Choose preferred delivery window',
      'Easy plan changes (demo)',
    ],
  },
  {
    id: 'monthly-family',
    name: 'Monthly Family',
    frequency: 'monthly',
    bottles: 36,
    price: 1299,
    description: 'Larger pack for families or frequent hosts. Maximum convenience and value.',
    features: [
      '36 bottles per month',
      'Best per-bottle value (illustrative)',
      'Multiple delivery addresses (proposed)',
      'Subscription dashboard (demo)',
    ],
  },
];
