import type { Testimonial } from '../types';

/** Fictional sample testimonials for prototype purposes only. */
export const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Aisha K.',
    role: 'College student, Bengaluru',
    content:
      'The Lemon Mint is my go-to between lectures. Light, refreshing and easy to carry in my bag. Looking forward to trying more flavours!',
    rating: 5,
  },
  {
    id: '2',
    name: 'Rohan M.',
    role: 'Software engineer, Pune',
    content:
      'Mango Burst reminds me of summer holidays. Great for afternoon desk breaks. Hope the subscription option launches soon.',
    rating: 5,
  },
  {
    id: '3',
    name: 'Priya S.',
    role: 'Marketing associate, Mumbai',
    content:
      'I like that the ingredient list is clear. Berry Fresh has a nice balance — not too sweet. Would recommend trying the range.',
    rating: 4,
  },
];
