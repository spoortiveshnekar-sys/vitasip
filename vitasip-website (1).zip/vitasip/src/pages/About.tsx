import { Link } from 'react-router-dom';
import { ArrowRight, Target, Eye, Heart } from 'lucide-react';

export default function About() {
  return (
    <div className="bg-white">
      <section className="bg-gradient-to-br from-lime-green/30 to-white py-16 lg:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="font-heading text-4xl sm:text-5xl font-bold text-dark-green">About VitaSip</h1>
          <p className="mt-4 text-lg text-dark-green/70 max-w-2xl mx-auto">
            A fictional FMCG beverage brand created for an academic website and digital marketing project.
          </p>
        </div>
      </section>

      <section className="py-16 lg:py-20">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 prose prose-lg">
          <h2 className="font-heading text-2xl font-bold text-dark-green">Why VitaSip was conceptualised</h2>
          <p className="text-dark-green/80 leading-relaxed">
            Young consumers in India’s Tier 1 and Tier 2 cities — college students aged 18–24 and working
            professionals aged 22–35 — often look for convenient, affordable, and enjoyable drinks that fit
            between classes, meetings and commute. VitaSip imagines a brand that answers that need with
            fruit-based flavours, clear packaging information and simple online purchasing options.
          </p>

          <h2 className="font-heading text-2xl font-bold text-dark-green mt-10">Our focus</h2>
          <p className="text-dark-green/80 leading-relaxed">
            Flavour and convenience sit at the centre of the concept. We prioritise transparent product
            information over unsupported health claims. Every ingredient list and sample nutrition panel is
            presented so visitors can make their own informed choices.
          </p>

          <div className="grid sm:grid-cols-3 gap-6 mt-12 not-prose">
            {[
              { icon: Target, title: 'Mission', text: 'Make refreshing beverage options accessible and convenient for young Indian consumers.' },
              { icon: Eye, title: 'Vision', text: 'Become a go-to everyday drink brand for students and professionals across key Indian cities.' },
              { icon: Heart, title: 'Values', text: 'Flavour first, clear communication, affordability and respect for the customer’s time.' },
            ].map((item) => (
              <div key={item.title} className="rounded-2xl border border-gray-100 bg-lime-green/10 p-6 text-center">
                <item.icon className="mx-auto h-8 w-8 text-fresh-green mb-3" />
                <h3 className="font-heading font-semibold text-dark-green">{item.title}</h3>
                <p className="mt-2 text-sm text-dark-green/70">{item.text}</p>
              </div>
            ))}
          </div>

          <h2 className="font-heading text-2xl font-bold text-dark-green mt-12">Future ambitions</h2>
          <p className="text-dark-green/80 leading-relaxed">
            Looking ahead, the brand concept includes expanding the flavour range, refining packaging, building
            distribution in more cities and offering reliable subscription packs. Founder details and company
            registration information remain placeholders until a real commercial launch.
          </p>

          <div className="mt-12 not-prose">
            <Link
              to="/products"
              className="inline-flex items-center gap-2 rounded-full bg-fresh-green px-6 py-3 text-sm font-semibold text-white hover:bg-dark-green transition-colors"
            >
              Discover Our Products
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
