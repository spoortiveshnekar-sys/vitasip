import { useState } from 'react';
import { User, Package, MapPin, Heart, CreditCard } from 'lucide-react';

export default function Account() {
  const [tab, setTab] = useState<'login' | 'signup' | 'dashboard'>('login');

  if (tab === 'dashboard') {
    return (
      <div className="bg-gray-50 min-h-screen py-12">
        <div className="mx-auto max-w-5xl px-4">
          <h1 className="font-heading text-3xl font-bold text-dark-green mb-2">My Account</h1>
          <p className="text-sm text-dark-green/50 mb-8">
            Demo account view. Authentication is not secure or functional without backend configuration.
          </p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { icon: Package, label: 'Order History', desc: 'Sample orders would appear here' },
              { icon: MapPin, label: 'Saved Addresses', desc: 'Add delivery addresses' },
              { icon: Heart, label: 'Saved Products', desc: 'Your wishlist' },
              { icon: CreditCard, label: 'Subscriptions', desc: 'Manage demo plans' },
              { icon: User, label: 'Profile', desc: 'Edit name and contact' },
            ].map((item) => (
              <div key={item.label} className="rounded-2xl bg-white border border-gray-100 p-5 shadow-sm">
                <item.icon className="h-6 w-6 text-fresh-green mb-2" />
                <h3 className="font-heading font-semibold text-dark-green">{item.label}</h3>
                <p className="text-sm text-dark-green/60 mt-1">{item.desc}</p>
              </div>
            ))}
          </div>
          <button
            type="button"
            onClick={() => setTab('login')}
            className="mt-8 text-sm text-fresh-green hover:underline"
          >
            Sign out (demo)
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen flex items-center justify-center py-16 px-4">
      <div className="w-full max-w-md rounded-2xl bg-white border border-gray-100 shadow-sm p-8">
        <h1 className="font-heading text-2xl font-bold text-dark-green text-center">
          {tab === 'login' ? 'Sign In' : 'Create Account'}
        </h1>
        <p className="text-center text-xs text-dark-green/40 mt-2 mb-6">
          Demo authentication only — not secure. Backend required for real accounts.
        </p>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            setTab('dashboard');
          }}
          className="space-y-4"
        >
          {tab === 'signup' && (
            <div>
              <label className="block text-sm font-medium text-dark-green mb-1">Full name</label>
              <input required className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm" />
            </div>
          )}
          <div>
            <label className="block text-sm font-medium text-dark-green mb-1">Email</label>
            <input type="email" required className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-dark-green mb-1">Password</label>
            <input type="password" required className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm" />
          </div>
          <button
            type="submit"
            className="w-full rounded-full bg-fresh-green py-3 text-sm font-semibold text-white hover:bg-dark-green"
          >
            {tab === 'login' ? 'Sign In (Demo)' : 'Create Account (Demo)'}
          </button>
        </form>
        <p className="mt-4 text-center text-sm text-dark-green/60">
          {tab === 'login' ? (
            <>
              No account?{' '}
              <button type="button" onClick={() => setTab('signup')} className="text-fresh-green hover:underline">
                Sign up
              </button>
            </>
          ) : (
            <>
              Already have an account?{' '}
              <button type="button" onClick={() => setTab('login')} className="text-fresh-green hover:underline">
                Sign in
              </button>
            </>
          )}
        </p>
      </div>
    </div>
  );
}
