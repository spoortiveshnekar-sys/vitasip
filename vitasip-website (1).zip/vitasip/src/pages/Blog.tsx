import { Link } from 'react-router-dom';
import { blogPosts } from '../data/blog';

export default function Blog() {
  return (
    <div className="bg-gray-50 min-h-screen">
      <section className="bg-white border-b py-12">
        <div className="mx-auto max-w-7xl px-4">
          <h1 className="font-heading text-3xl sm:text-4xl font-bold text-dark-green">Blog</h1>
          <p className="mt-2 text-dark-green/70">
            Tips and ideas around everyday refreshment. Sample content for SEO and content marketing demonstration.
          </p>
        </div>
      </section>

      <section className="py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <article
                key={post.id}
                className="rounded-2xl bg-white border border-gray-100 overflow-hidden shadow-sm hover:shadow-md transition-shadow"
              >
                <img
                  src={post.image}
                  alt=""
                  className="h-40 w-full object-cover"
                />
                <div className="p-5">
                  <time className="text-xs text-dark-green/50">{post.date}</time>
                  <h2 className="font-heading font-semibold text-lg text-dark-green mt-1">
                    <Link to={`/blog/${post.slug}`} className="hover:text-fresh-green">
                      {post.title}
                    </Link>
                  </h2>
                  <p className="mt-2 text-sm text-dark-green/70 line-clamp-2">{post.summary}</p>
                  <Link
                    to={`/blog/${post.slug}`}
                    className="mt-4 inline-block text-sm font-medium text-fresh-green hover:underline"
                  >
                    Read More →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
