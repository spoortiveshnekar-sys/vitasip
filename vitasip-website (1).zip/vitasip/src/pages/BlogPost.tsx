import { useParams, Link } from 'react-router-dom';
import { getPostBySlug } from '../data/blog';
import { ArrowLeft } from 'lucide-react';

export default function BlogPost() {
  const { slug } = useParams<{ slug: string }>();
  const post = getPostBySlug(slug || '');

  if (!post) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center">
        <h1 className="font-heading text-2xl font-bold">Article not found</h1>
        <Link to="/blog" className="text-fresh-green hover:underline mt-4 inline-block">
          Back to blog
        </Link>
      </div>
    );
  }

  return (
    <article className="bg-white">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 py-12">
        <Link to="/blog" className="inline-flex items-center gap-1 text-sm text-fresh-green hover:underline mb-6">
          <ArrowLeft className="h-4 w-4" /> All articles
        </Link>
        <img src={post.image} alt="" className="w-full h-56 object-cover rounded-2xl mb-8" />
        <time className="text-sm text-dark-green/50">{post.date} · {post.author}</time>
        <h1 className="font-heading text-3xl sm:text-4xl font-bold text-dark-green mt-2">{post.title}</h1>
        <div
          className="mt-8 prose prose-sm sm:prose max-w-none text-dark-green/80"
          dangerouslySetInnerHTML={{ __html: post.content }}
        />
        <div className="mt-8 flex flex-wrap gap-2">
          {post.tags.map((t) => (
            <span key={t} className="rounded-full bg-lime-green/40 px-3 py-0.5 text-xs text-fresh-green">
              {t}
            </span>
          ))}
        </div>
        <p className="mt-10 text-xs text-dark-green/40">
          Sample content only. No medical or nutritional claims are made. Link to relevant products for exploration.
        </p>
        <Link to="/products" className="mt-4 inline-block text-fresh-green font-medium hover:underline">
          Explore VitaSip flavours →
        </Link>
      </div>
    </article>
  );
}
