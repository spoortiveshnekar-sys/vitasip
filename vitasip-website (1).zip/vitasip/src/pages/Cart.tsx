import { Link } from 'react-router-dom';
import { Minus, Plus, Trash2, ShoppingBag } from 'lucide-react';
import { useCart } from '../context/CartContext';

export default function Cart() {
  const { items, updateQuantity, removeItem, subtotal, totalItems, clearCart } = useCart();

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-20 text-center">
        <ShoppingBag className="mx-auto h-16 w-16 text-dark-green/30 mb-4" />
        <h1 className="font-heading text-2xl font-bold text-dark-green">Your cart is empty</h1>
        <p className="mt-2 text-dark-green/60">Add some VitaSip flavours to get started.</p>
        <Link
          to="/products"
          className="mt-6 inline-flex rounded-full bg-fresh-green px-6 py-3 text-sm font-semibold text-white hover:bg-dark-green"
        >
          Browse Products
        </Link>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen py-10">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <h1 className="font-heading text-3xl font-bold text-dark-green mb-8">
          Shopping Cart ({totalItems} {totalItems === 1 ? 'item' : 'items'})
        </h1>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-4">
            {items.map((item) => (
              <div
                key={item.product.id}
                className="flex gap-4 rounded-2xl bg-white border border-gray-100 p-4 shadow-sm"
              >
                <img
                  src={item.product.image}
                  alt={item.product.name}
                  className="h-24 w-16 object-contain"
                />
                <div className="flex-1">
                  <h3 className="font-heading font-semibold text-dark-green">{item.product.name}</h3>
                  <p className="text-sm text-dark-green/50">{item.packSize}</p>
                  <p className="mt-1 font-medium text-fresh-green">₹{item.product.price}</p>
                  <div className="mt-3 flex items-center gap-3">
                    <div className="flex items-center rounded-full border border-gray-200">
                      <button
                        type="button"
                        onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                        className="p-1.5"
                        aria-label="Decrease"
                      >
                        <Minus className="h-3.5 w-3.5" />
                      </button>
                      <span className="w-8 text-center text-sm">{item.quantity}</span>
                      <button
                        type="button"
                        onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                        className="p-1.5"
                        aria-label="Increase"
                      >
                        <Plus className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeItem(item.product.id)}
                      className="p-1.5 text-red-500 hover:bg-red-50 rounded-full"
                      aria-label="Remove"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                <div className="text-right font-semibold text-dark-green">
                  ₹{item.product.price * item.quantity}
                </div>
              </div>
            ))}
            <button
              type="button"
              onClick={clearCart}
              className="text-sm text-dark-green/50 hover:text-red-500"
            >
              Clear cart
            </button>
          </div>

          <div className="rounded-2xl bg-white border border-gray-100 p-6 shadow-sm h-fit">
            <h2 className="font-heading font-semibold text-lg text-dark-green mb-4">Order Summary</h2>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-dark-green/70">Subtotal</span>
              <span className="font-medium">₹{subtotal}</span>
            </div>
            <div className="flex justify-between text-sm mb-4">
              <span className="text-dark-green/70">Shipping</span>
              <span className="text-dark-green/50">Calculated at checkout</span>
            </div>
            <div className="border-t border-gray-100 pt-4 flex justify-between font-bold text-lg">
              <span>Total</span>
              <span className="text-fresh-green">₹{subtotal}</span>
            </div>
            <button
              type="button"
              onClick={() =>
                alert(
                  'Checkout and payment integration are not configured. This is a demo cart. Connect a payment provider and backend to enable real orders.'
                )
              }
              className="mt-6 w-full rounded-full bg-fresh-green py-3 text-sm font-semibold text-white hover:bg-dark-green transition-colors"
            >
              Proceed to Checkout
            </button>
            <p className="mt-3 text-xs text-center text-dark-green/40">
              Demo only — no real payments are processed.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
