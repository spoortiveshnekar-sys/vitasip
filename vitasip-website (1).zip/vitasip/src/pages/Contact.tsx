import { useState, type FormEvent } from 'react';
import { Send } from 'lucide-react';

const enquiryTypes = [
  'Product information',
  'Order support',
  'Delivery',
  'Subscriptions',
  'Business partnerships',
  'General enquiry',
];

const faqs = [
  {
    q: 'What flavours does VitaSip offer?',
    a: 'Currently three sample flavours: Lemon Mint, Mango Burst and Berry Fresh. All details on this site are illustrative.',
  },
  {
    q: 'Are the prices real?',
    a: 'No. Prices and pack sizes are sample data for the prototype until actual product specifications are available.',
  },
  {
    q: 'How do subscriptions work?',
    a: 'Subscription plans are proposed only. Recurring billing and automated delivery require backend and payment configuration.',
  },
  {
    q: 'How can I get a refund?',
    a: 'Refund and shipping policies are draft placeholders. See the Shipping & Refunds page for the current draft text.',
  },
];

export default function Contact() {
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus('loading');
    setErrorMsg('');

    const form = e.currentTarget;
    const data = new FormData(form);

    // Simulate API — real implementation would POST to /api/enquiries
    try {
      // Check if API is available
      const res = await fetch('/api/enquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: data.get('name'),
          email: data.get('email'),
          phone: data.get('phone') || undefined,
          organisation: data.get('organisation') || undefined,
          enquiryType: data.get('enquiryType'),
          orderNumber: data.get('orderNumber') || undefined,
          message: data.get('message'),
          consent: data.get('consent') === 'on',
        }),
      });

      if (!res.ok) throw new Error('API not configured');
      setStatus('success');
      form.reset();
    } catch {
      setStatus('error');
      setErrorMsg(
        'The contact form backend is not configured yet. Please set up Neon PostgreSQL and the /api/enquiries endpoint. Your message was not stored.'
      );
    }
  };

  return (
    <div className="bg-gray-50 min-h-screen">
      <section className="bg-white border-b py-12">
        <div className="mx-auto max-w-7xl px-4 text-center">
          <h1 className="font-heading text-3xl sm:text-4xl font-bold text-dark-green">Contact Us</h1>
          <p className="mt-2 text-dark-green/70">
            Enquiries, partnerships and support. Placeholder contact details for this prototype.
          </p>
        </div>
      </section>

      <section className="py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid lg:grid-cols-2 gap-12">
          <div>
            <form onSubmit={handleSubmit} className="rounded-2xl bg-white border border-gray-100 p-6 sm:p-8 shadow-sm space-y-5">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-dark-green mb-1">
                  Full name *
                </label>
                <input
                  id="name"
                  name="name"
                  required
                  className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-fresh-green"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-dark-green mb-1">
                  Email *
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-fresh-green"
                />
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-dark-green mb-1">
                    Phone (optional)
                  </label>
                  <input
                    id="phone"
                    name="phone"
                    type="tel"
                    className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-fresh-green"
                  />
                </div>
                <div>
                  <label htmlFor="organisation" className="block text-sm font-medium text-dark-green mb-1">
                    Organisation (optional)
                  </label>
                  <input
                    id="organisation"
                    name="organisation"
                    className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-fresh-green"
                  />
                </div>
              </div>
              <div>
                <label htmlFor="enquiryType" className="block text-sm font-medium text-dark-green mb-1">
                  Enquiry type *
                </label>
                <select
                  id="enquiryType"
                  name="enquiryType"
                  required
                  className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-fresh-green"
                >
                  <option value="">Select…</option>
                  {enquiryTypes.map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="orderNumber" className="block text-sm font-medium text-dark-green mb-1">
                  Order number (optional)
                </label>
                <input
                  id="orderNumber"
                  name="orderNumber"
                  className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-fresh-green"
                />
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-dark-green mb-1">
                  Message *
                </label>
                <textarea
                  id="message"
                  name="message"
                  required
                  rows={4}
                  className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-fresh-green"
                />
              </div>
              <div className="flex items-start gap-2">
                <input id="consent" name="consent" type="checkbox" required className="mt-1" />
                <label htmlFor="consent" className="text-sm text-dark-green/70">
                  I agree to the processing of my data as described in the Privacy Policy. *
                </label>
              </div>

              {status === 'error' && (
                <p className="text-sm text-red-600 bg-red-50 rounded-lg p-3">{errorMsg}</p>
              )}
              {status === 'success' && (
                <p className="text-sm text-green-700 bg-green-50 rounded-lg p-3">
                  Thank you! Your enquiry has been received.
                </p>
              )}

              <button
                type="submit"
                disabled={status === 'loading'}
                className="inline-flex items-center gap-2 rounded-full bg-fresh-green px-6 py-3 text-sm font-semibold text-white hover:bg-dark-green disabled:opacity-60 transition-colors"
              >
                <Send className="h-4 w-4" />
                {status === 'loading' ? 'Sending…' : 'Send Message'}
              </button>
            </form>
          </div>

          <div>
            <h2 className="font-heading text-xl font-semibold text-dark-green mb-4">Help Centre / FAQs</h2>
            <div className="space-y-4">
              {faqs.map((f) => (
                <details key={f.q} className="rounded-xl bg-white border border-gray-100 p-4">
                  <summary className="font-medium text-dark-green cursor-pointer">{f.q}</summary>
                  <p className="mt-2 text-sm text-dark-green/70">{f.a}</p>
                </details>
              ))}
            </div>
            <div className="mt-8 rounded-xl bg-lime-green/20 p-5 text-sm text-dark-green/80">
              <p className="font-medium">Placeholder contact</p>
              <p className="mt-1">Email: hello@vitasip.example</p>
              <p>Phone: +91 98765 43210</p>
              <p>Address: [Placeholder], Bengaluru, India</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
