import { Link } from 'react-router-dom';
import { ArrowRight, Leaf, Sparkles, Package, Truck } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { products } from '../data/products';
import { testimonials } from '../data/testimonials';

export default function Home() {
  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-lime-green/40 via-white to-mango-yellow/20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in-up">
              <p className="inline-flex items-center gap-2 rounded-full bg-fresh-green/10 px-3 py-1 text-sm font-medium text-fresh-green mb-6">
                <Leaf className="h-4 w-4" /> Sip Healthy. Live Happy.
              </p>
              <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-extrabold text-dark-green leading-tight">
                Refresh Your Day with{' '}
                <span className="text-fresh-green">VitaSip</span>
              </h1>
              <p className="mt-6 text-lg text-dark-green/70 max-w-lg leading-relaxed">
                Discover refreshing flavours made for your everyday moments. Explore VitaSip’s range of fruity
                beverages designed to fit your busy lifestyle.
              </p>
              <div className="mt-8 flex flex-wrap gap-4">
                <Link
                  to="/products"
                  className="inline-flex items-center gap-2 rounded-full bg-fresh-green px-6 py-3 text-base font-semibold text-white shadow-lg shadow-fresh-green/25 hover:bg-dark-green transition-colors"
                >
                  Explore Our Products
                  <ArrowRight className="h-5 w-5" />
                </Link>
                <Link
                  to="/products"
                  className="inline-flex items-center gap-2 rounded-full border-2 border-fresh-green px-6 py-3 text-base font-semibold text-fresh-green hover:bg-lime-green/30 transition-colors"
                >
                  Shop Now
                </Link>
              </div>
            </div>

            <div className="relative flex justify-center items-end gap-2 sm:gap-4 h-[380px] lg:h-[440px]">
              <div className="absolute inset-0 bg-gradient-to-t from-lime-green/20 to-transparent rounded-3xl" />
              <img
                src="/images/lemon-mint.svg"
                alt="VitaSip Lemon Mint bottle mockup"
                className="relative z-10 h-[70%] w-auto object-contain drop-shadow-xl animate-float"
                style={{ animationDelay: '0s' }}
              />
              <img
                src="/images/mango-burst.svg"
                alt="VitaSip Mango Burst bottle mockup"
                className="relative z-20 h-[90%] w-auto object-contain drop-shadow-2xl animate-float"
                style={{ animationDelay: '0.5s' }}
              />
              <img
                src="/images/berry-fresh.svg"
                alt="VitaSip Berry Fresh bottle mockup"
                className="relative z-10 h-[70%] w-auto object-contain drop-shadow-xl animate-float"
                style={{ animationDelay: '1s' }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 lg:py-24 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="font-heading text-3xl sm:text-4xl font-bold text-dark-green">
              Meet Your New Favourite Flavours.
            </h2>
            <p className="mt-4 text-dark-green/70">
              Three refreshing options designed for college students, young professionals and anyone who wants
              convenient everyday drinks. Sample prices shown.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-16 lg:py-20 bg-lime-green/20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="font-heading text-3xl sm:text-4xl font-bold text-dark-green text-center mb-12">
            Refreshment That Fits Your Lifestyle.
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Package,
                title: 'Convenient for everyday moments',
                desc: 'Portable bottles ready for campus, office or travel. No complicated prep — just open and enjoy.',
              },
              {
                icon: Sparkles,
                title: 'Exciting flavours to explore',
                desc: 'Lemon Mint, Mango Burst and Berry Fresh give you variety without leaving your comfort zone.',
              },
              {
                icon: Leaf,
                title: 'Clear product information',
                desc: 'Transparent ingredient lists and sample nutrition details so you know what you are sipping.',
              },
            ].map((b) => (
              <div
                key={b.title}
                className="rounded-2xl bg-white p-8 shadow-sm border border-gray-100 text-center"
              >
                <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-fresh-green/10 text-fresh-green">
                  <b.icon className="h-7 w-7" />
                </div>
                <h3 className="font-heading font-semibold text-lg text-dark-green">{b.title}</h3>
                <p className="mt-2 text-sm text-dark-green/70 leading-relaxed">{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Brand intro */}
      <section className="py-16 lg:py-24 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="flex justify-center">
              <div className="relative rounded-3xl bg-gradient-to-br from-fresh-green to-dark-green p-8 sm:p-12">
                <img
                  src="/images/mango-burst.svg"
                  alt="VitaSip product mockup"
                  className="h-64 sm:h-80 w-auto object-contain drop-shadow-2xl"
                />
              </div>
            </div>
            <div>
              <h2 className="font-heading text-3xl sm:text-4xl font-bold text-dark-green">
                A Fresh Take on Everyday Refreshment.
              </h2>
              <p className="mt-6 text-dark-green/70 leading-relaxed">
                VitaSip is a fictional beverage brand conceptualised for young Indian consumers who want enjoyable
                fruit flavours in convenient packaging. We focus on clear product information, approachable pricing
                and a shopping experience that fits busy college and work schedules.
              </p>
              <p className="mt-4 text-dark-green/70 leading-relaxed">
                From Bengaluru to Jaipur, the idea is simple: make refreshing drinks easy to discover, purchase and
                enjoy — whether as a single bottle or a recurring pack.
              </p>
              <Link
                to="/about"
                className="mt-8 inline-flex items-center gap-2 rounded-full bg-fresh-green px-6 py-3 text-sm font-semibold text-white hover:bg-dark-green transition-colors"
              >
                About VitaSip
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Bestsellers */}
      <section className="py-16 lg:py-20 bg-gray-50">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="font-heading text-3xl sm:text-4xl font-bold text-dark-green text-center mb-4">
            Find Your Favourite VitaSip.
          </h2>
          <p className="text-center text-dark-green/60 mb-10 text-sm">
            Featured flavours · Sample ratings · Demo data only
          </p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products
              .filter((p) => p.isBestSeller)
              .map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
          </div>
        </div>
      </section>

      {/* Subscription promo */}
      <section className="py-16 lg:py-24 bg-fresh-green text-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <Truck className="mx-auto h-12 w-12 text-lime-green mb-6" />
          <h2 className="font-heading text-3xl sm:text-4xl font-bold">
            Your Favourite Flavours, Delivered Regularly.
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-lime-green/90 leading-relaxed">
            Explore proposed weekly and monthly beverage packs. Pricing and benefits shown are illustrative until
            the business model and delivery partners are finalised. Subscription features are demo-only in this
            prototype.
          </p>
          <Link
            to="/subscriptions"
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-lime-green px-6 py-3 text-base font-semibold text-dark-green hover:bg-white transition-colors"
          >
            Explore Subscription Plans
            <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 lg:py-20 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="font-heading text-3xl sm:text-4xl font-bold text-dark-green text-center mb-4">
            What Our Customers Might Say.
          </h2>
          <p className="text-center text-sm text-dark-green/50 mb-10">
            Fictional sample testimonials for prototype purposes only — not genuine customer feedback.
          </p>
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((t) => (
              <blockquote
                key={t.id}
                className="rounded-2xl bg-lime-green/15 border border-lime-green/30 p-6"
              >
                <div className="flex gap-1 text-mango-yellow mb-3">
                  {Array.from({ length: t.rating }).map((_, i) => (
                    <span key={i}>★</span>
                  ))}
                </div>
                <p className="text-dark-green/80 text-sm leading-relaxed">“{t.content}”</p>
                <footer className="mt-4">
                  <cite className="not-italic font-semibold text-dark-green">{t.name}</cite>
                  <p className="text-xs text-dark-green/50">{t.role}</p>
                </footer>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-16 bg-gradient-to-r from-lime-green/30 to-mango-yellow/20">
        <div className="mx-auto max-w-xl px-4 text-center">
          <h2 className="font-heading text-2xl sm:text-3xl font-bold text-dark-green">
            Stay Fresh with VitaSip.
          </h2>
          <p className="mt-3 text-dark-green/70">
            Get updates about new flavours, special offers, and upcoming launches.
          </p>
          <form
            className="mt-6 flex flex-col sm:flex-row gap-3"
            onSubmit={(e) => {
              e.preventDefault();
              alert(
                'Newsletter backend is not configured. This is a visual prototype. Connect Neon PostgreSQL and an API route to enable real subscriptions.'
              );
            }}
          >
            <input
              type="email"
              required
              placeholder="Your email address"
              className="flex-1 rounded-full border border-gray-200 px-5 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-fresh-green"
              aria-label="Email for newsletter"
            />
            <button
              type="submit"
              className="rounded-full bg-fresh-green px-6 py-3 text-sm font-semibold text-white hover:bg-dark-green transition-colors"
            >
              Subscribe
            </button>
          </form>
          <p className="mt-3 text-xs text-dark-green/50">
            By subscribing you agree to our Privacy Policy. Backend setup required for actual delivery.
          </p>
        </div>
      </section>
    </>
  );
}
