import { Link } from 'react-router-dom';
import { Search, ShoppingBag, Smile, ArrowRight } from 'lucide-react';

const steps = [
  {
    icon: Search,
    title: 'Explore',
    desc: 'Discover the available VitaSip flavours — Lemon Mint, Mango Burst and Berry Fresh — and read clear product information.',
  },
  {
    icon: ShoppingBag,
    title: 'Choose',
    desc: 'Select your preferred drink, pack size and quantity. Add to cart or explore proposed subscription packs.',
  },
  {
    icon: Smile,
    title: 'Enjoy',
    desc: 'Complete the purchase (once payment and delivery are configured) and receive order updates. Sip and refresh.',
  },
];

export default function HowItWorks() {
  return (
    <div className="bg-white">
      <section className="bg-gradient-to-br from-lime-green/30 to-white py-16">
        <div className="mx-auto max-w-7xl px-4 text-center">
          <h1 className="font-heading text-4xl font-bold text-dark-green">
            Your VitaSip Shopping Journey, Made Simple.
          </h1>
          <p className="mt-4 text-dark-green/70 max-w-xl mx-auto">
            Three straightforward steps from discovery to enjoyment.
          </p>
        </div>
      </section>

      <section className="py-16 lg:py-20">
        <div className="mx-auto max-w-5xl px-4">
          <div className="grid md:grid-cols-3 gap-8">
            {steps.map((s, i) => (
              <div key={s.title} className="relative text-center">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-fresh-green text-white text-xl font-bold mb-4">
                  {i + 1}
                </div>
                <s.icon className="mx-auto h-8 w-8 text-fresh-green mb-3" />
                <h3 className="font-heading text-xl font-semibold text-dark-green">{s.title}</h3>
                <p className="mt-2 text-sm text-dark-green/70 leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
          <div className="mt-12 text-center">
            <Link
              to="/products"
              className="inline-flex items-center gap-2 rounded-full bg-fresh-green px-6 py-3 text-sm font-semibold text-white hover:bg-dark-green"
            >
              Start Shopping
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
