export default function Privacy() {
  return (
    <div className="bg-white py-12">
      <div className="mx-auto max-w-3xl px-4 prose prose-sm">
        <h1 className="font-heading text-3xl font-bold text-dark-green">Privacy Policy</h1>
        <p className="text-sm text-dark-green/50">Draft for prototype — requires legal review before commercial use.</p>
        <h2>Information we may collect</h2>
        <p>Name, email, phone, enquiry details, newsletter preferences, and technical data such as browser type when you use the site.</p>
        <h2>How we use information</h2>
        <p>To respond to enquiries, send newsletters (with consent), improve the website, and fulfil orders once e-commerce is configured.</p>
        <h2>Newsletter consent</h2>
        <p>You may unsubscribe at any time. We only send marketing communications with your explicit consent.</p>
        <h2>Cookies and analytics</h2>
        <p>We may use essential cookies and analytics tools. Details will be updated when tracking is implemented.</p>
        <h2>Data security</h2>
        <p>We aim to protect data with appropriate technical measures. No system is completely secure.</p>
        <h2>Your rights</h2>
        <p>Depending on applicable law you may request access, correction or deletion of your personal data. Contact hello@vitasip.example.</p>
        <h2>Contact</h2>
        <p>For privacy questions: hello@vitasip.example (placeholder).</p>
      </div>
    </div>
  );
}
