import { useParams, Link } from 'react-router-dom';
import { useState } from 'react';
import { ShoppingCart, Minus, Plus, Star, ArrowLeft } from 'lucide-react';
import { getProductBySlug, getRelatedProducts } from '../data/products';
import { useCart } from '../context/CartContext';
import ProductCard from '../components/ProductCard';

export default function ProductDetail() {
  const { slug } = useParams<{ slug: string }>();
  const product = getProductBySlug(slug || '');
  const { addItem } = useCart();
  const [qty, setQty] = useState(1);

  if (!product) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-20 text-center">
        <h1 className="font-heading text-2xl font-bold text-dark-green">Product not found</h1>
        <Link to="/products" className="mt-4 inline-block text-fresh-green hover:underline">
          Back to products
        </Link>
      </div>
    );
  }

  const related = getRelatedProducts(product.id);

  return (
    <div className="bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <Link to="/products" className="inline-flex items-center gap-1 text-sm text-fresh-green hover:underline mb-6">
          <ArrowLeft className="h-4 w-4" /> All products
        </Link>

        <div className="grid lg:grid-cols-2 gap-12">
          <div className="rounded-3xl bg-gradient-to-b from-lime-green/20 to-white p-8 flex items-center justify-center min-h-[400px]">
            <img
              src={product.image}
              alt={`${product.name} conceptual bottle mockup`}
              className="h-80 w-auto object-contain drop-shadow-xl"
            />
          </div>

          <div>
            <div className="flex items-center gap-2 text-mango-yellow mb-2">
              <Star className="h-4 w-4 fill-current" />
              <span className="text-sm text-dark-green/70">
                {product.rating} ({product.reviewCount} sample reviews)
              </span>
            </div>
            <h1 className="font-heading text-3xl sm:text-4xl font-bold text-dark-green">{product.name}</h1>
            <p className="mt-3 text-dark-green/70 leading-relaxed">{product.description}</p>
            <div className="mt-6 flex items-baseline gap-2">
              <span className="text-3xl font-bold text-fresh-green">₹{product.price}</span>
              <span className="text-sm text-dark-green/50">/ {product.packSize} · Sample price</span>
            </div>
            <p className="mt-1 text-sm text-green-700">{product.inStock ? 'In stock' : 'Out of stock'}</p>

            <div className="mt-8 flex items-center gap-4">
              <div className="flex items-center rounded-full border border-gray-200">
                <button
                  type="button"
                  onClick={() => setQty(Math.max(1, qty - 1))}
                  className="p-2.5 hover:bg-gray-50 rounded-l-full"
                  aria-label="Decrease quantity"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span className="w-10 text-center font-medium">{qty}</span>
                <button
                  type="button"
                  onClick={() => setQty(qty + 1)}
                  className="p-2.5 hover:bg-gray-50 rounded-r-full"
                  aria-label="Increase quantity"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>
              <button
                type="button"
                onClick={() => addItem(product, qty)}
                className="inline-flex items-center gap-2 rounded-full bg-fresh-green px-6 py-3 text-sm font-semibold text-white hover:bg-dark-green transition-colors"
              >
                <ShoppingCart className="h-4 w-4" /> Add to Cart
              </button>
              <Link
                to="/cart"
                onClick={() => addItem(product, qty)}
                className="inline-flex items-center rounded-full border-2 border-fresh-green px-6 py-3 text-sm font-semibold text-fresh-green hover:bg-lime-green/20 transition-colors"
              >
                Buy Now
              </Link>
            </div>

            <div className="mt-10 space-y-6 border-t border-gray-100 pt-8">
              <div>
                <h3 className="font-heading font-semibold text-dark-green">Ingredients</h3>
                <p className="mt-1 text-sm text-dark-green/70">{product.ingredients.join(', ')}</p>
              </div>
              <div>
                <h3 className="font-heading font-semibold text-dark-green">Nutrition (sample per serving)</h3>
                <ul className="mt-2 grid grid-cols-2 gap-2 text-sm text-dark-green/70">
                  {product.nutrition.map((n) => (
                    <li key={n.label} className="flex justify-between border-b border-gray-50 pb-1">
                      <span>{n.label}</span>
                      <span className="font-medium">{n.value}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 className="font-heading font-semibold text-dark-green">Allergens &amp; Storage</h3>
                <p className="mt-1 text-sm text-dark-green/70">{product.allergens}</p>
                <p className="mt-1 text-sm text-dark-green/70">{product.storage}</p>
              </div>
              <p className="text-xs text-dark-green/40">
                Delivery information and real payment processing require backend configuration. This is a visual
                prototype.
              </p>
            </div>
          </div>
        </div>

        {related.length > 0 && (
          <div className="mt-20">
            <h2 className="font-heading text-2xl font-bold text-dark-green mb-6">You may also like</h2>
            <div className="grid sm:grid-cols-2 gap-8">
              {related.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
