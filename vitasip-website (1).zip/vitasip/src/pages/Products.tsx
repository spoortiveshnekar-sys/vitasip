import { useMemo, useState } from 'react';
import ProductCard from '../components/ProductCard';
import { products } from '../data/products';

export default function Products() {
  const [search, setSearch] = useState('');
  const [flavour, setFlavour] = useState('all');
  const [sort, setSort] = useState('popularity');

  const filtered = useMemo(() => {
    let list = [...products];
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.shortDescription.toLowerCase().includes(q) ||
          p.flavour.includes(q)
      );
    }
    if (flavour !== 'all') {
      list = list.filter((p) => p.flavour === flavour);
    }
    if (sort === 'price-asc') list.sort((a, b) => a.price - b.price);
    else if (sort === 'price-desc') list.sort((a, b) => b.price - a.price);
    else list.sort((a, b) => b.rating - a.rating);
    return list;
  }, [search, flavour, sort]);

  return (
    <div className="bg-gray-50 min-h-screen">
      <section className="bg-white border-b border-gray-100 py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h1 className="font-heading text-3xl sm:text-4xl font-bold text-dark-green">Our Products</h1>
          <p className="mt-2 text-dark-green/70">
            Explore the full VitaSip range. All prices and pack sizes are sample data for this prototype.
          </p>
        </div>
      </section>

      <section className="py-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row gap-4 mb-8">
            <input
              type="search"
              placeholder="Search flavours..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="flex-1 rounded-full border border-gray-200 px-5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-fresh-green"
              aria-label="Search products"
            />
            <select
              value={flavour}
              onChange={(e) => setFlavour(e.target.value)}
              className="rounded-full border border-gray-200 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-fresh-green"
              aria-label="Filter by flavour"
            >
              <option value="all">All flavours</option>
              <option value="lemon-mint">Lemon Mint</option>
              <option value="mango-burst">Mango Burst</option>
              <option value="berry-fresh">Berry Fresh</option>
            </select>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              className="rounded-full border border-gray-200 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-fresh-green"
              aria-label="Sort products"
            >
              <option value="popularity">Sort by popularity</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
            </select>
          </div>

          {filtered.length === 0 ? (
            <p className="text-center text-dark-green/60 py-16">No products match your filters.</p>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {filtered.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
