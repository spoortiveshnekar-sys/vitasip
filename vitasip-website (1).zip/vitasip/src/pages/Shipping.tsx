export default function Shipping() {
  return (
    <div className="bg-white py-12">
      <div className="mx-auto max-w-3xl px-4 prose prose-sm">
        <h1 className="font-heading text-3xl font-bold text-dark-green">Shipping &amp; Refund Policy</h1>
        <p className="text-sm text-dark-green/50">Draft placeholder — not operational.</p>
        <h2>Delivery</h2>
        <p>Once a fulfilment partner is configured, estimated delivery times and serviceable pin codes will be published here.</p>
        <h2>Shipping charges</h2>
        <p>Illustrative free-delivery thresholds may apply. Actual rates will be calculated at checkout.</p>
        <h2>Cancellations</h2>
        <p>Order cancellation windows and processes will be defined when the order system goes live.</p>
        <h2>Refunds</h2>
        <p>Refund eligibility for damaged or incorrect items will follow standard consumer protection practices once the business is operational.</p>
      </div>
    </div>
  );
}
