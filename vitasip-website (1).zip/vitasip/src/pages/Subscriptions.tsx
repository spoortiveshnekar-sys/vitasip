import { useState } from 'react';
import { Check } from 'lucide-react';
import { subscriptionPlans } from '../data/subscriptions';

export default function Subscriptions() {
  const [selected, setSelected] = useState<string | null>(null);

  return (
    <div className="bg-gray-50 min-h-screen">
      <section className="bg-white border-b py-12">
        <div className="mx-auto max-w-7xl px-4 text-center">
          <h1 className="font-heading text-3xl sm:text-4xl font-bold text-dark-green">
            Make VitaSip Part of Your Routine.
          </h1>
          <p className="mt-3 text-dark-green/70 max-w-2xl mx-auto">
            Proposed weekly and monthly beverage packs. Pricing, delivery schedules and management features are
            illustrative and demo-only until a backend and payment provider are configured.
          </p>
        </div>
      </section>

      <section className="py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {subscriptionPlans.map((plan) => (
              <div
                key={plan.id}
                className={`relative rounded-2xl bg-white border p-6 shadow-sm flex flex-col ${
                  plan.popular ? 'border-fresh-green ring-2 ring-fresh-green/30' : 'border-gray-100'
                }`}
              >
                {plan.popular && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-fresh-green px-3 py-0.5 text-xs font-semibold text-white">
                    Popular
                  </span>
                )}
                <h3 className="font-heading font-semibold text-lg text-dark-green">{plan.name}</h3>
                <p className="text-xs text-dark-green/50 capitalize mt-1">{plan.frequency}</p>
                <p className="mt-4">
                  <span className="text-3xl font-bold text-fresh-green">₹{plan.price}</span>
                  <span className="text-sm text-dark-green/50"> / {plan.frequency}</span>
                </p>
                <p className="mt-1 text-sm text-dark-green/60">{plan.bottles} bottles</p>
                <p className="mt-3 text-sm text-dark-green/70 flex-1">{plan.description}</p>
                <ul className="mt-4 space-y-2">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm text-dark-green/70">
                      <Check className="h-4 w-4 text-fresh-green shrink-0 mt-0.5" />
                      {f}
                    </li>
                  ))}
                </ul>
                <button
                  type="button"
                  onClick={() => {
                    setSelected(plan.id);
                    alert(
                      `Plan "${plan.name}" selected in demo mode. Recurring billing, automated deliveries and cancellation are not functional until backend configuration.`
                    );
                  }}
                  className={`mt-6 w-full rounded-full py-2.5 text-sm font-semibold transition-colors ${
                    selected === plan.id
                      ? 'bg-dark-green text-white'
                      : 'bg-fresh-green text-white hover:bg-dark-green'
                  }`}
                >
                  {selected === plan.id ? 'Selected (Demo)' : 'Choose Your Plan'}
                </button>
              </div>
            ))}
          </div>
          <p className="mt-8 text-center text-xs text-dark-green/40">
            All subscription features are demonstrative. No real charges or deliveries occur in this prototype.
          </p>
        </div>
      </section>
    </div>
  );
}
