export default function Terms() {
  return (
    <div className="bg-white py-12">
      <div className="mx-auto max-w-3xl px-4 prose prose-sm">
        <h1 className="font-heading text-3xl font-bold text-dark-green">Terms &amp; Conditions</h1>
        <p className="text-sm text-dark-green/50">Draft for prototype — requires legal review before commercial use.</p>
        <h2>Website use</h2>
        <p>This website is a demonstration for an imaginary brand. Content is provided for academic and portfolio purposes.</p>
        <h2>Products and pricing</h2>
        <p>All products, prices, pack sizes and availability are sample data and may change.</p>
        <h2>Orders and payments</h2>
        <p>Real order processing and payment collection are not enabled in this prototype.</p>
        <h2>Intellectual property</h2>
        <p>VitaSip branding and content on this site are conceptual. Do not use for commercial purposes without permission.</p>
        <h2>Limitation of liability</h2>
        <p>The site is provided as-is for demonstration. We accept no liability for decisions made based on prototype content.</p>
      </div>
    </div>
  );
}
