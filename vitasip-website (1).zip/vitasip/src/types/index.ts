export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  shortDescription: string;
  price: number;
  packSize: string;
  flavour: 'lemon-mint' | 'mango-burst' | 'berry-fresh';
  category: string;
  image: string;
  images: string[];
  ingredients: string[];
  nutrition: { label: string; value: string }[];
  allergens: string;
  storage: string;
  inStock: boolean;
  rating: number;
  reviewCount: number;
  isBestSeller?: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
  packSize: string;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  frequency: 'weekly' | 'monthly';
  bottles: number;
  price: number;
  description: string;
  features: string[];
  popular?: boolean;
}

export interface BlogPost {
  id: string;
  slug: string;
  title: string;
  summary: string;
  content: string;
  image: string;
  date: string;
  author: string;
  tags: string[];
}

export interface EnquiryFormData {
  name: string;
  email: string;
  phone?: string;
  organisation?: string;
  enquiryType: string;
  orderNumber?: string;
  message: string;
  consent: boolean;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  content: string;
  rating: number;
  avatar?: string;
}
